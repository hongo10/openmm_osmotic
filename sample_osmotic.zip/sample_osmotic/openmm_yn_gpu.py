#from openmm.app import *
#from openmm import *
#from openmm.unit import *
#from sys import stdout
#from simtk.unit import *

from __future__ import print_function
import argparse
import sys
import os

from omm_readinputs import *
from omm_readparams import *
from omm_vfswitch import *
from omm_barostat import *
from omm_restraints import *

from simtk.unit import *
from simtk.openmm import *
from simtk.openmm.app import *

parser = argparse.ArgumentParser()
parser.add_argument('-i', dest='inpfile', help='Input parameter file', required=True)
parser.add_argument('-p', dest='psffile', help='Input CHARMM PSF file', required=True)
parser.add_argument('-c', dest='crdfile', help='Input CHARMM CRD file', required=True)
parser.add_argument('-t', dest='toppar', help='Input CHARMM-GUI toppar stream file', required=True)
parser.add_argument('-b', dest='sysinfo', help='Input CHARMM-GUI sysinfo stream file (optional)', default=None)
parser.add_argument('-icrst', metavar='RSTFILE', dest='icrst', help='Input CHARMM RST file (optional)', default=None)
parser.add_argument('-irst', metavar='RSTFILE', dest='irst', help='Input restart file (optional)', default=None)
parser.add_argument('-ichk', metavar='CHKFILE', dest='ichk', help='Input checkpoint file (optional)', default=None)
parser.add_argument('-opdb', metavar='PDBFILE', dest='opdb', help='Output PDB file (optional)', default=None)
parser.add_argument('-orst', metavar='RSTFILE', dest='orst', help='Output restart file (optional)', default=None)
parser.add_argument('-ochk', metavar='CHKFILE', dest='ochk', help='Output checkpoint file (optional)', default=None)
parser.add_argument('-odcd', metavar='DCDFILE', dest='odcd', help='Output trajectory file (optional)', default=None)

args = parser.parse_args()

print("Loading parameters")
inputs = read_inputs(args.inpfile)
params = read_params(args.toppar)
psf = read_top(args.psffile)
crd = read_crd(args.crdfile)
if args.sysinfo:
    psf = read_box(psf, args.sysinfo)
else:
    psf = gen_box(psf, crd)

'''
params = read_params('toppar.str')
psf = CharmmPsfFile('./files/sod_acet.drude.xplor.psf')
crd = CharmmCrdFile('./files/sod_acet_min_drude.crd')
psf.setBox(48.000*angstrom,48.000*angstrom,99.67719692950000*angstrom)

system = psf.createSystem(params,
                          nonbondedMethod = PME,
                          nonbondedCutoff = 1.2*nanometers,
                          switchDistance  = 1.0*nanometers,
                          constraints = AllBonds,
                          ewaldErrorTolerance=0.0001)

'''

# Build system
if inputs.vdw == 'Switch':
    system = psf.createSystem(params, nonbondedMethod=inputs.coulomb,
                              nonbondedCutoff=inputs.r_off*nanometers,
                              switchDistance=inputs.r_on*nanometers,
                              constraints=inputs.cons,
                              ewaldErrorTolerance=inputs.ewald_Tol)
    for force in system.getForces():
        if isinstance(force, NonbondedForce): force.setUseDispersionCorrection(True)
        if isinstance(force, CustomNonbondedForce) and force.getNumTabulatedFunctions() == 2:
            force.setUseLongRangeCorrection(True)
elif inputs.vdw == 'Force-switch':
    system = psf.createSystem(params, nonbondedMethod=inputs.coulomb,
                              nonbondedCutoff=inputs.r_off*nanometers,
                              constraints=inputs.cons,
                              ewaldErrorTolerance=inputs.ewald_Tol)
    system = vfswitch(system, psf, inputs)
elif inputs.vdw == 'LJPME':
    system = psf.createSystem(params, nonbondedMethod=inputs.coulomb,
                              nonbondedCutoff=inputs.r_off*nanometers,
                              constraints=inputs.cons,
                              ewaldErrorTolerance=inputs.ewald_Tol)

if inputs.pcouple == 'yes': system = barostat(system, inputs)
if inputs.rest == 'yes':    system = restraints(system, psf, crd, inputs)

'''
hyper = CustomBondForce('step(r-rhyper)*((r-rhyper) *khyper)^powh')
hyper.addGlobalParameter('khyper', 100.0)
hyper.addGlobalParameter('rhyper', 0.02)
hyper.addGlobalParameter('powh', 6)
system.addForce(hyper)
for d in psf.drudepair_list:
    hyper.addBond(d[0],d[1],[])
'''

z_size=2.4
force_membrane = CustomExternalForce('k* (pz^2);\
                                    pz = max(0,delta);\
                                    delta = r - width;\
                                    r = abs(periodicdistance(x, y, z, x, y, z0));' )


force_membrane.addGlobalParameter('k',5.0*kilocalories_per_mole/angstroms**2)
force_membrane.addGlobalParameter('width',2.4*nanometers)
force_membrane.addGlobalParameter('z0',0*nanometers)


system.addForce(force_membrane)

IonNum1=128
IonNum2=128
AtomIonNum2=15
IonList = []
for i in range(IonNum1):
    IonList.append(i*2)

for i in range (IonNum2):
    IonList.append(IonNum1*2+i*AtomIonNum2+5)

for i in IonList:
    force_membrane.addParticle(i,[])

integrator = DrudeLangevinIntegrator(inputs.temp*kelvin, inputs.fric_coeff/picosecond, inputs.drude_temp*kelvin, inputs.drude_fric_coeff/picosecond, inputs.dt*picoseconds)
integrator.setMaxDrudeDistance(inputs.drude_hardwall) # Drude Hardwall


'''yiling original code
barostat = MonteCarloAnisotropicBarostat( (1.0, 1.0, 1.0)*bar, 298.0*kelvin, False, False, True, 100 )
system.addForce(barostat)
'''

platform = Platform.getPlatformByName('CUDA')
prop = dict(CudaPrecision='mixed')

simulation = Simulation(psf.topology, system, integrator, platform, prop)
simulation.context.setPositions(crd.positions)


if args.icrst:
    charmm_rst = read_charmm_rst(args.icrst)
    simulation.context.setPositions(charmm_rst.positions)
    simulation.context.setVelocities(charmm_rst.velocities)
    simulation.context.setPeriodicBoxVectors(charmm_rst.box[0], charmm_rst.box[1], charmm_rst.box[2])
if args.irst:
    with open(args.irst, 'r') as f:
        simulation.context.setState(XmlSerializer.deserialize(f.read()))
if args.ichk:
    with open(args.ichk, 'rb') as f:
        simulation.context.loadCheckpoint(f.read())

# Drude VirtualSites
simulation.context.computeVirtualSites()


print("\nInitial system energy")
print(simulation.context.getState(getEnergy=True).getPotentialEnergy())


# Energy minimization
if inputs.mini_nstep > 0:
    print("\nEnergy minimization: %s steps" % inputs.mini_nstep)
    simulation.minimizeEnergy(tolerance=inputs.mini_Tol*kilojoule/mole, maxIterations=inputs.mini_nstep)
    print(simulation.context.getState(getEnergy=True).getPotentialEnergy())

# Generate initial velocities
if inputs.gen_vel == 'yes':
    print("\nGenerate initial velocities")
    if inputs.gen_seed:
        simulation.context.setVelocitiesToTemperature(inputs.gen_temp, inputs.gen_seed)
    else:
        simulation.context.setVelocitiesToTemperature(inputs.gen_temp)

# Production
if inputs.nstep > 0:
    print("\nMD run: %s steps" % inputs.nstep)
    if inputs.nstdcd > 0:
        if not args.odcd: args.odcd = 'output.dcd'
        simulation.reporters.append(DCDReporter(args.odcd, inputs.nstdcd))
    simulation.reporters.append(
        StateDataReporter(sys.stdout, inputs.nstout, step=True, time=True, potentialEnergy=True, temperature=True, progress=True,
                          remainingTime=True, speed=True, totalSteps=inputs.nstep, separator='\t')
    )
    simulation.step(inputs.nstep)



# Write restart file
if not (args.orst or args.ochk): args.orst = 'output.rst'
if args.orst:
    state = simulation.context.getState( getPositions=True, getVelocities=True )
    with open(args.orst, 'w') as f:
        f.write(XmlSerializer.serialize(state))
if args.ochk:
    with open(args.ochk, 'wb') as f:
        f.write(simulation.context.createCheckpoint())
if args.opdb:
    crd = simulation.context.getState(getPositions=True).getPositions()
    PDBFile.writeFile(psf.topology, crd, open(args.opdb, 'w'))


'''
yiling orignial code

mystate= simulation.context.getState(getPositions=True,enforcePeriodicBox=True,getVelocities=True)
#positions = simulation.context.getState(getPositions=True,enforcePeriodicBox=True).getPositions()
positions= mystate.getPositions()
velocities = mystate.getVelocities()
Boxes = mystate.getPeriodicBoxVectors(asNumpy=True)

#z_size = Boxes.item((2,2))
#print(z_size)

#updated_positions = [ Vec3(pos.x, pos.y, pos.z - z_size/2) for pos in positions ]
#print(positions[5].z)
#print(updated_positions[5].z)

simulation.context.reinitialize()
simulation.context.setPositions(positions)
simulation.context.setVelocities(velocities)

print("I am okay")

simulation.reporters.append(PDBReporter('output4.pdb', 10))
simulation.reporters.append(StateDataReporter('sys.stdout', 10, step=True,
        potentialEnergy=True, temperature=True, volume=True, remainingTime=True, speed=True, totalSteps=100, separator='\t'))
simulation.reporters.append(DCDReporter('output4.dcd', 10))

state = simulation.context.getState( getPositions=True, getVelocities=True )

simulation.step(100)


#state = simulation.context.getState( getPositions=True, getVelocities=True )
with open("out.rst", 'w') as f:
    f.write(XmlSerializer.serialize(state))

#simulation.step(10000000)

'''
